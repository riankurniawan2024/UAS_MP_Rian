package com.developer

import android.os.Bundle
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.android.material.button.MaterialButton
import net.objecthunter.exp4j.ExpressionBuilder

class MainActivity : AppCompatActivity() {

    private lateinit var solutionTV: TextView
    private lateinit var resultTV: TextView
    private var currentSolution = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        solutionTV = findViewById(R.id.tv_solution)
        resultTV = findViewById(R.id.tv_result)

        val buttonAC = findViewById<MaterialButton>(R.id.button_ac)
        val buttonOBracket = findViewById<MaterialButton>(R.id.button_open_bracket)
        val buttonCBracket = findViewById<MaterialButton>(R.id.button_close_bracket)
        val buttonDevide = findViewById<MaterialButton>(R.id.button_devide)
        val button7 = findViewById<MaterialButton>(R.id.button_7)
        val button8 = findViewById<MaterialButton>(R.id.button_8)
        val button9 = findViewById<MaterialButton>(R.id.button_9)
        val buttonMultiply = findViewById<MaterialButton>(R.id.button_multiply)
        val button4 = findViewById<MaterialButton>(R.id.button_4)
        val button5 = findViewById<MaterialButton>(R.id.button_5)
        val button6 = findViewById<MaterialButton>(R.id.button_6)
        val buttonMinus = findViewById<MaterialButton>(R.id.button_minus)
        val button1 = findViewById<MaterialButton>(R.id.button_1)
        val button2 = findViewById<MaterialButton>(R.id.button_2)
        val button3 = findViewById<MaterialButton>(R.id.button_3)
        val buttonPlus = findViewById<MaterialButton>(R.id.button_plus)
        val button0 = findViewById<MaterialButton>(R.id.button_0)
        val buttonDot = findViewById<MaterialButton>(R.id.button_point)
        val buttonC = findViewById<MaterialButton>(R.id.button_c)
        // val buttonEqual = findViewById<MaterialButton>(R.id.button_eq)

        // Set OnClickListener untuk semua tombol
        button1.setOnClickListener { appendChar("1");calculateResult() }
        button2.setOnClickListener { appendChar("2");calculateResult() }
        button3.setOnClickListener { appendChar("3");calculateResult() }
        button4.setOnClickListener { appendChar("4");calculateResult() }
        button5.setOnClickListener { appendChar("5");calculateResult() }
        button6.setOnClickListener { appendChar("6");calculateResult() }
        button7.setOnClickListener { appendChar("7");calculateResult() }
        button8.setOnClickListener { appendChar("8");calculateResult() }
        button9.setOnClickListener { appendChar("9");calculateResult() }
        button0.setOnClickListener { appendChar("0");calculateResult() }
        buttonDot.setOnClickListener { appendChar(".") }
        buttonOBracket.setOnClickListener { appendChar("(") }
        buttonCBracket.setOnClickListener { appendChar(")");calculateResult() }
        buttonDevide.setOnClickListener { appendChar("/") }
        buttonMultiply.setOnClickListener { appendChar("*") }
        buttonMinus.setOnClickListener { appendChar("-") }
        buttonPlus.setOnClickListener { appendChar("+") }

        // buttonEqual.setOnClickListener {
        //    calculateResult()
        // }

        buttonC.setOnClickListener {
            currentSolution = currentSolution.dropLast(1)
            solutionTV.text = currentSolution

            calculateResult()

            if (currentSolution.isEmpty()) {
                resultTV.text = "0"
            }
        }

        buttonAC.setOnClickListener {
            currentSolution = ""
            solutionTV.text = ""
            resultTV.text = "" // Tambahkan baris ini untuk membersihkan resultTV
        }

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }

    private fun appendChar(char: String) {
        currentSolution += char
        solutionTV.text = currentSolution
    }

    private fun calculateResult() {
        try {
            val expression = ExpressionBuilder(currentSolution).build()
            val result = expression.evaluate()

            // Periksa apakah result adalah bilangan bulat
            if (result % 1 == 0.0) {
                resultTV.text = result.toInt().toString() // Tampilkan sebagai integer
            } else {
                resultTV.text = result.toString() // Tampilkan sebagai double
            }

        } catch (e: Exception) {
            // Handle error
        }
    }
}